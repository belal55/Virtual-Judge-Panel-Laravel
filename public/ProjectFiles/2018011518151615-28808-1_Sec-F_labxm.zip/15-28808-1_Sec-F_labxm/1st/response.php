<html>
	<body>
		<?php
			if($_SERVER["REQUEST_METHOD"] == "POST")
			{
				
				if($_POST["fname"]=="")
				{
					print "name can't be empty!!";
				}else if(str_word_count($_POST["fname"])<2)
				{
					print "name can't be less than two words!!";
				}
			}
		
		?>
	</body>
</html>