<html>
	<body>
		<?php
			if($_SERVER["REQUEST_METHOD"] == "POST")
			{
				
				if($_POST["dd"]=="" || $_POST["mm"]=="" || $_POST["yyy"]=="")
				{
					print "field can't be empty!!";
				}else if($_POST["dd"]>31 || $_POST["dd"]<1 )
				{
					print "day field is invalid!!";
				}else if($_POST["mm"]>12 || $_POST["mm"]<1 )
				{
					print "Month field is invalid!!";
				}else if($_POST["yyy"]>2016 || $_POST["yyy"]<1900 )
				{
					print "Year field is invalid!!";
				}
			}
		
		?>
	</body>
</html>